"""Бизнес-логика HotelBook. Здесь размещаются правила БП-01…БП-06."""

from datetime import date
from decimal import Decimal

ROOMS = [
    {"id": 1, "number": "301", "category": "Стандарт", "capacity": 2, "price": Decimal("18000.00")},
    {"id": 2, "number": "402", "category": "Комфорт", "capacity": 3, "price": Decimal("25000.00")},
    {"id": 3, "number": "501", "category": "Люкс", "capacity": 4, "price": Decimal("42000.00")},
]
EXTRAS = {"breakfast": Decimal("3500.00"), "transfer": Decimal("5000.00"), "late_checkout": Decimal("4000.00")}

def validate_stay(check_in: date, check_out: date, guests: int) -> None:
    """Проверить даты и количество гостей (ФТ-01, БП-01/02 интерфейса)."""
    if check_in < date.today():
        raise ValueError("Дата заезда не может быть в прошлом.")
    if check_out <= check_in:
        raise ValueError("Дата выезда должна быть позже даты заезда.")
    if guests < 1 or guests > 10:
        raise ValueError("Укажите количество гостей от 1 до 10.")

def search_rooms(check_in: date, check_out: date, guests: int) -> list[dict]:
    """Вернуть подходящие демонстрационные номера с расчётом стоимости."""
    validate_stay(check_in, check_out, guests)
    nights = (check_out - check_in).days
    result = []
    for room in ROOMS:
        if room["capacity"] >= guests:
            result.append({
                **room,
                "nights": nights,
                "total": room["price"] * nights,
                "cancellation": "100% возврат при отмене не позднее чем за 24 часа до заезда.",
            })
    return result

def calculate_total(room_id: int, nights: int, extras: list[str] | None = None) -> Decimal:
    """Рассчитать стоимость проживания и услуг (ФТ-05, БП-03)."""
    room = next((item for item in ROOMS if item["id"] == room_id), None)
    if room is None:
        raise ValueError("Номер не найден.")
    if nights < 1:
        raise ValueError("Количество ночей должно быть положительным.")
    extra_total = sum((EXTRAS.get(code, Decimal("0.00")) for code in (extras or [])), Decimal("0.00"))
    return room["price"] * nights + extra_total

def reserve_room(room_id: int, check_in: date, check_out: date, guests: int) -> dict:
    """Демонстрационная заглушка резерва на 15 минут (БП-01, БП-02)."""
    matches = search_rooms(check_in, check_out, guests)
    room = next((item for item in matches if item["id"] == room_id), None)
    if room is None:
        raise ValueError("Номер недоступен или не подходит по вместимости.")
    return {"booking_id": "HB-DEMO-0001", "room_id": room_id, "status": "Ожидает оплаты",
            "expires_in_minutes": 15, "total": str(room["total"])}

def process_payment(booking_id: str, attempt: int, gateway_confirmed: bool, reserve_active: bool) -> dict:
    """Модель результата шлюза; успех нельзя устанавливать по сообщению браузера."""
    if attempt > 3:
        return {"status": "Неуспешно", "error": "Превышен лимит попыток оплаты."}
    if not reserve_active:
        return {"status": "Неуспешно", "error": "Срок резерва истёк."}
    if not gateway_confirmed:
        if attempt >= 3:
            return {"status": "Неуспешно", "error": "Достигнут лимит в три попытки оплаты."}
        return {"status": "Ожидает оплаты", "error": "Платёж не подтверждён платёжным шлюзом."}
    return {"status": "Подтверждено", "booking_id": booking_id}

def cancellation_refund(check_in: date, now: date, amount: Decimal) -> Decimal:
    """Рассчитать возврат по учебному тарифу (БП-05)."""
    return amount if (check_in - now).days >= 1 else Decimal("0.00")
