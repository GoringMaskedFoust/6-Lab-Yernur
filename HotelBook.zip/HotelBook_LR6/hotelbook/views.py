from datetime import date
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST
from . import services

def home(request):
    """Экран Э-01: форма поиска номера."""
    return render(request, "hotelbook/search.html")

@require_GET
def api_rooms(request):
    """GET /api/rooms/?check_in=YYYY-MM-DD&check_out=YYYY-MM-DD&guests=2"""
    try:
        check_in = date.fromisoformat(request.GET["check_in"])
        check_out = date.fromisoformat(request.GET["check_out"])
        guests = int(request.GET.get("guests", "1"))
        rooms = services.search_rooms(check_in, check_out, guests)
        payload = [{"id": r["id"], "number": r["number"], "category": r["category"],
                    "capacity": r["capacity"], "price_per_night": str(r["price"]),
                    "nights": r["nights"], "total": str(r["total"])} for r in rooms]
        return JsonResponse({"items": payload}, json_dumps_params={"ensure_ascii": False})
    except (KeyError, ValueError) as exc:
        return JsonResponse({"error": str(exc)}, status=400, json_dumps_params={"ensure_ascii": False})

@require_POST
def api_reserve(request):
    """POST /api/bookings/reserve/ — демонстрационное создание 15-минутного резерва."""
    import json
    try:
        data = json.loads(request.body or "{}")
        result = services.reserve_room(int(data["room_id"]), date.fromisoformat(data["check_in"]),
                                       date.fromisoformat(data["check_out"]), int(data["guests"]))
        return JsonResponse(result, status=201, json_dumps_params={"ensure_ascii": False})
    except (KeyError, ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400, json_dumps_params={"ensure_ascii": False})

@require_POST
def api_payment(request, booking_id):
    """POST /api/bookings/<id>/pay/ — имитация проверенного ответа шлюза."""
    import json
    data = json.loads(request.body or "{}")
    result = services.process_payment(booking_id, int(data.get("attempt", 1)),
                                      bool(data.get("gateway_confirmed", False)),
                                      bool(data.get("reserve_active", True)))
    status_code = 200 if result["status"] == "Подтверждено" else 422
    return JsonResponse(result, status=status_code, json_dumps_params={"ensure_ascii": False})
