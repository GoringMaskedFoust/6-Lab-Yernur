from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("api/rooms/", views.api_rooms, name="api-rooms"),
    path("api/bookings/reserve/", views.api_reserve, name="api-reserve"),
    path("api/bookings/<str:booking_id>/pay/", views.api_payment, name="api-payment"),
]
