from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from . import services

class HotelBookBusinessTests(TestCase):
    def test_total_includes_nights_and_extras(self):
        total = services.calculate_total(1, 2, ["breakfast"])
        self.assertEqual(total, Decimal("39500.00"))

    def test_payment_requires_gateway_confirmation(self):
        result = services.process_payment("HB-1", 1, False, True)
        self.assertEqual(result["status"], "Ожидает оплаты")

    def test_third_failed_payment_closes_booking(self):
        result = services.process_payment("HB-1", 3, False, True)
        self.assertEqual(result["status"], "Неуспешно")

    def test_search_returns_capacity_compatible_rooms(self):
        tomorrow = date.today() + timedelta(days=1)
        rooms = services.search_rooms(tomorrow, tomorrow + timedelta(days=2), 3)
        self.assertTrue(all(room["capacity"] >= 3 for room in rooms))

    def test_home_screen_opens(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "HotelBook")

    def test_rooms_api_returns_json(self):
        tomorrow = date.today() + timedelta(days=1)
        response = self.client.get("/api/rooms/", {"check_in": tomorrow.isoformat(),
                                  "check_out": (tomorrow + timedelta(days=1)).isoformat(), "guests": 2})
        self.assertEqual(response.status_code, 200)
        self.assertIn("items", response.json())
