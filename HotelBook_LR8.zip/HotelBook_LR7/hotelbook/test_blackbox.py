"""Дополнительные тесты «чёрного ящика» для UC-01 (ЛР №8)."""
from datetime import date, datetime, timedelta
from decimal import Decimal
from unittest.mock import Mock, patch
from uuid import uuid4

from django.test import TestCase
from django.utils import timezone

from . import services
from .models import Booking, BookingNight, Customer, Room


NOW = timezone.make_aware(datetime(2026, 11, 10, 12, 30))


class HotelBookBlackBoxBase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.room = Room.objects.create(
            number="501", category=Room.Category.STANDARD,
            capacity=2, price_per_night=Decimal("18000.00"),
        )

    def setUp(self):
        self.clock = patch("django.utils.timezone.now", return_value=NOW)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.local_clock = patch("django.utils.timezone.localdate", return_value=NOW.date())
        self.local_clock.start()
        self.addCleanup(self.local_clock.stop)

    def reserve(self, *, check_in=None, check_out=None, guests=2, room_id=None):
        return services.reserve_room(
            room_id or self.room.pk,
            check_in or NOW.date() + timedelta(days=1),
            check_out or NOW.date() + timedelta(days=3),
            guests, "Тестовый Клиент", "+77011234567",
            "test@example.com", True, [],
        )

    def api_reserve_payload(self, **overrides):
        payload = {
            "room_id": str(self.room.pk),
            "check_in": (NOW.date() + timedelta(days=1)).isoformat(),
            "check_out": (NOW.date() + timedelta(days=3)).isoformat(),
            "guests": 2, "full_name": "Новый Клиент",
            "phone": "+77019999999", "email": "new@example.com",
            "consent": True, "extras": [],
        }
        payload.update(overrides)
        return payload


class DateAndInputBoundaryTests(HotelBookBlackBoxBase):
    def test_check_in_yesterday_is_rejected(self):
        """БП-01: недопустимый класс — дата заезда в прошлом."""
        with self.assertRaises(services.BookingError):
            services.validate_stay(NOW.date() - timedelta(days=1),
                                   NOW.date() + timedelta(days=1), 1)

    def test_check_out_equal_or_before_check_in_is_rejected(self):
        """БП-01: граничные значения даты выезда — равна заезду и раньше."""
        for offset in (0, -1):
            with self.subTest(offset=offset):
                with self.assertRaises(services.BookingError):
                    services.validate_stay(
                        NOW.date() + timedelta(days=1),
                        NOW.date() + timedelta(days=1 + offset), 1,
                    )

    def test_guest_count_boundaries_and_invalid_classes(self):
        """БП-02: проверка обеих допустимых границ и значений за границами."""
        for guests in (1, 10):
            with self.subTest(guests=guests):
                services.validate_stay(NOW.date(), NOW.date() + timedelta(days=1), guests)
        for guests in (0, 11):
            with self.subTest(guests=guests):
                with self.assertRaises(services.BookingError):
                    services.validate_stay(
                        NOW.date(), NOW.date() + timedelta(days=1), guests
                    )

    def test_api_rejects_invalid_phone_before_service(self):
        """Формат ввода: телефон не соответствует +7XXXXXXXXXX, сервис не вызывается."""
        with patch("hotelbook.views.services.reserve_room") as service_stub:
            response = self.client.post(
                "/api/bookings/reserve/",
                data=json_bytes(self.api_reserve_payload(phone="8701")),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 400)
        service_stub.assert_not_called()

    def test_api_rejects_malformed_json(self):
        """Контракт API: некорректное JSON-тело возвращает 400."""
        response = self.client.post(
            "/api/bookings/reserve/", data="{broken", content_type="application/json"
        )
        self.assertEqual(response.status_code, 400)

    def test_unknown_room_is_conflict(self):
        """Е3: несуществующий идентификатор номера возвращает исключение 409."""
        with self.assertRaises(services.RoomUnavailableError):
            self.reserve(room_id=uuid4())


class ReservationAndPaymentStateTests(HotelBookBlackBoxBase):
    def test_reservation_expires_after_fifteen_minutes(self):
        """БП-01/Е2: перевод часов за границу 15 минут делает резерв недействительным."""
        booking = self.reserve()
        self.assertEqual(booking.status, Booking.Status.PENDING)
        after_deadline = NOW + timedelta(minutes=15, seconds=1)
        with patch("django.utils.timezone.now", return_value=after_deadline):
            with self.assertRaises(services.ReservationExpiredError):
                services.process_payment(booking.pk, True)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.FAILED)
        self.assertEqual(booking.nights.count(), 0)

    def test_missing_expiry_is_treated_as_expired(self):
        """БП-01: резерв без expires_at не может быть оплачен."""
        booking = self.reserve()
        Booking.objects.filter(pk=booking.pk).update(expires_at=None)
        with self.assertRaises(services.ReservationExpiredError):
            services.process_payment(booking.pk, True)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.FAILED)

    def test_payment_for_unknown_booking_is_rejected(self):
        """Контракт API/сервиса: неизвестный идентификатор брони даёт BookingError."""
        with self.assertRaises(services.BookingError):
            services.process_payment(uuid4(), True)

    def test_payment_attempts_boundary(self):
        """БП-04/Е1: первая и вторая ошибки дают 402, третья — 422 и закрытие."""
        booking = self.reserve()
        for attempt in (1, 2):
            with self.subTest(attempt=attempt):
                with self.assertRaises(services.PaymentDeclinedError):
                    services.process_payment(booking.pk, False)
                booking.refresh_from_db()
                self.assertEqual(booking.payment_attempts, attempt)
                self.assertEqual(booking.status, Booking.Status.PENDING)
        with self.assertRaises(services.TooManyPaymentAttemptsError):
            services.process_payment(booking.pk, False)
        booking.refresh_from_db()
        self.assertEqual(booking.payment_attempts, 3)
        self.assertEqual(booking.status, Booking.Status.FAILED)

    def test_successful_payment_confirms_booking(self):
        """БП-03: только подтверждённый ответ переводит резерв в подтверждённую бронь."""
        booking = self.reserve()
        result = services.process_payment(booking.pk, True)
        self.assertEqual(result.status, Booking.Status.CONFIRMED)

    def test_payment_for_non_pending_booking_is_rejected(self):
        """Диаграмма состояний: повторная оплата подтверждённой брони запрещена."""
        booking = self.reserve()
        services.process_payment(booking.pk, True)
        with self.assertRaises(services.InvalidStateError):
            services.process_payment(booking.pk, True)

    def test_cancellation_refund_threshold(self):
        """БП-05: возврат 100% при сроке не менее 24 часов, иначе 0."""
        amount = Decimal("18000.00")
        today = NOW.date()
        self.assertEqual(
            services.cancellation_refund(today + timedelta(days=1), today, amount),
            amount,
        )
        self.assertEqual(
            services.cancellation_refund(today, today, amount), Decimal("0.00")
        )


def json_bytes(value):
    import json
    return json.dumps(value)


class ApiViewStubTests(HotelBookBlackBoxBase):
    def test_api_reserve_returns_created_when_service_succeeds(self):
        """Интеграция сверху вниз: API возвращает 201 при успешной заглушке сервиса."""
        fake = Mock(
            pk=uuid4(), expires_at=NOW + timedelta(minutes=15),
            total=Decimal("36000.00"),
        )
        fake.get_status_display.return_value = "Ожидает оплаты"
        with patch("hotelbook.views.services.reserve_room", return_value=fake) as stub:
            response = self.client.post(
                "/api/bookings/reserve/",
                data=json_bytes(self.api_reserve_payload()),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 201)
        stub.assert_called_once()

    def test_api_reserve_maps_service_error_to_http_code(self):
        """Контракт API: исключение слоя логики преобразуется в HTTP 409."""
        with patch(
            "hotelbook.views.services.reserve_room",
            side_effect=services.RoomUnavailableError(),
        ) as stub:
            response = self.client.post(
                "/api/bookings/reserve/",
                data=json_bytes(self.api_reserve_payload()),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 409)
        stub.assert_called_once()

    def test_api_payment_maps_all_booking_errors(self):
        """Полиморфизм исключений: каждый наследник BookingError даёт свой HTTP-код."""
        cases = [
            (services.BookingError, 400),
            (services.RoomUnavailableError, 409),
            (services.CapacityExceededError, 422),
            (services.ReservationExpiredError, 410),
            (services.PaymentDeclinedError, 402),
            (services.TooManyPaymentAttemptsError, 422),
            (services.InvalidStateError, 409),
        ]
        booking_id = uuid4()
        for error_type, expected_status in cases:
            with self.subTest(error=error_type.__name__):
                with patch(
                    "hotelbook.views.services.process_payment",
                    side_effect=error_type(),
                ):
                    response = self.client.post(
                        f"/api/bookings/{booking_id}/payment-result/",
                        data='{"gateway_confirmed": true}',
                        content_type="application/json",
                    )
                self.assertEqual(response.status_code, expected_status)
