"""Интеграционные тесты представлений с заглушками слоя логики."""
import json
from datetime import timedelta
from decimal import Decimal
from unittest.mock import Mock, patch
from uuid import uuid4

from django.test import TestCase
from django.utils import timezone

from . import services
from .models import Room


class ApiServiceStubTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.room = Room.objects.create(
            number="601", category=Room.Category.STANDARD,
            capacity=2, price_per_night=Decimal("12000.00"),
        )

    def payload(self, **updates):
        data = {
            "room_id": str(self.room.pk),
            "check_in": (timezone.localdate() + timedelta(days=1)).isoformat(),
            "check_out": (timezone.localdate() + timedelta(days=2)).isoformat(),
            "guests": 1, "full_name": "Клиент Тест",
            "phone": "+77011234567", "email": "client@example.com",
            "consent": True, "extras": [],
        }
        data.update(updates)
        return json.dumps(data)

    def test_reserve_view_uses_service_stub_once(self):
        """Проверяет вызов бизнес-слоя и успешный HTTP-ответ."""
        booking = Mock(
            pk=uuid4(),
            expires_at=timezone.now() + timedelta(minutes=15),
            total=Decimal("12000.00"),
        )
        booking.get_status_display.return_value = "Ожидает оплаты"
        with patch("hotelbook.views.services.reserve_room", return_value=booking) as stub:
            response = self.client.post(
                "/api/bookings/reserve/", self.payload(),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 201)
        stub.assert_called_once()

    def test_reserve_view_maps_service_exception(self):
        """Проверяет преобразование исключения сервиса в HTTP 409."""
        with patch(
            "hotelbook.views.services.reserve_room",
            side_effect=services.RoomUnavailableError(),
        ) as stub:
            response = self.client.post(
                "/api/bookings/reserve/", self.payload(),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 409)
        stub.assert_called_once()

    def test_invalid_input_does_not_call_service(self):
        """Форма отклоняет неверный телефон до обращения к бизнес-слою."""
        with patch("hotelbook.views.services.reserve_room") as stub:
            response = self.client.post(
                "/api/bookings/reserve/", self.payload(phone="123"),
                content_type="application/json",
            )
        self.assertEqual(response.status_code, 400)
        stub.assert_not_called()
