# Белый ящик: `process_payment` — UC-01

## Граф потока управления

```mermaid
flowchart TD
    A([Вход: booking_id, gateway_confirmed]) --> B[Загрузить Booking]
    B --> C{Бронь найдена?}
    C -- Нет --> X1[BookingError / HTTP 400]
    C -- Да --> D{status = PENDING?}
    D -- Нет --> X2[InvalidStateError / HTTP 409]
    D -- Да --> E{expires_at отсутствует или <= now?}
    E -- Да --> F[status FAILED; удалить BookingNight]
    F --> Z[Сохранить транзакцию]
    E -- Нет --> G{gateway_confirmed?}
    G -- Да --> H[status CONFIRMED]
    H --> Z
    G -- Нет --> I[Увеличить payment_attempts]
    I --> J{payment_attempts >= 3?}
    J -- Да --> K[status FAILED; удалить ночи]
    J -- Нет --> L[Оставить PENDING]
    K --> Z
    L --> Z
    Z --> M{error задана?}
    M -- Да --> X3[Выбросить сохранённое исключение]
    M -- Нет --> R([Вернуть Booking])
```

## Цикломатическая сложность

В графе выделяются 8 предикатных проверок, если составное условие `not booking.expires_at or booking.expires_at <= timezone.now()` разложить на две независимые проверки: бронь найдена; статус ожидает оплаты; `expires_at` отсутствует; срок истёк; платёж подтверждён; достигнут лимит попыток; статус FAILED (нужно ли освободить ночи); ошибка задана.

- По формуле `V(G) = P + 1`: `8 + 1 = 9`.
- По формуле `V(G) = E − N + 2`: для окончательно отрисованного CFG необходимо пересчитать все узлы и рёбра по фактическим ветвям; это значение должно совпасть с 9.

Значение 9 — расчётная цикломатическая сложность по исходному коду с учётом обеих частей составного условия. Подтверждённый подсчёт E и N и фактическое покрытие требуется внести после запуска анализа на установленном проекте.

## Базисные пути и тесты

| Путь | Маршрут | Исход | Тест |
|---|---|---|---|
| P1 | Нет записи | `BookingError` | `test_payment_unknown_booking` (добавить при необходимости) |
| P2 | Запись найдена → статус не PENDING | `InvalidStateError` | `test_payment_for_non_pending_booking_is_rejected` |
| P3 | PENDING → срок истёк | `ReservationExpiredError`, FAILED | `test_reservation_expires_after_fifteen_minutes` |
| P4 | PENDING → срок активен → платёж успешен | CONFIRMED | `test_successful_payment_confirms_booking` |
| P5 | PENDING → активен → отказ 1/2 | `PaymentDeclinedError`, PENDING | `test_payment_attempts_boundary` |
| P6 | PENDING → активен → отказ 3 | `TooManyPaymentAttemptsError`, FAILED | `test_payment_attempts_boundary` |

## Составные условия
В `process_payment` есть составное условие `not booking.expires_at or booking.expires_at <= timezone.now()`. Обе части должны быть истинными и ложными в отдельных прогонах: отсутствие `expires_at` и истёкшее время. В дополнительный набор включены проверки истёкшего времени; отдельный сценарий `expires_at=None` отмечен как обязательный для завершения покрытия.
