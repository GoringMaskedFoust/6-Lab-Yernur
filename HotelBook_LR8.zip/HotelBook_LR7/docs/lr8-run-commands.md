# Команды завершения и проверки ЛР №8

```bash
# 1. Установка и проверка базового проекта
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
pip install coverage
python manage.py migrate
python manage.py test

# 2. Проверка стиля
ruff check .
ruff format --check .

# 3. Покрытие до/после — сначала сохранить исходный результат до добавления новых тестов
coverage run --branch manage.py test
coverage report -m hotelbook/services.py
coverage html

# 4. Ветка и коммиты
git switch -c test/uc-01
git add docs/test-plan.md docs/test-design.md
git commit -m "docs: add UC-01 test plan and design"
git add hotelbook/test_blackbox.py
git commit -m "test: add UC-01 black-box tests"
git add docs/control-flow.md
git commit -m "docs: document process payment control flow"
git add hotelbook/test_views_stub.py
git commit -m "test: cover API views with service stubs"
git add .github/ISSUE_TEMPLATE/defect.md docs/cross-test-cases.md
git commit -m "test: add cross-testing cases and defect template"
git add docs/test-report.md docs/lr8-run-commands.md
git commit -m "docs: add UC-01 test report and run guide"

# 5. После проверки и исправлений
git switch main
git merge --no-ff test/uc-01
git push origin main
git push origin test/uc-01
```

Не копировать в отчёт предполагаемые проценты покрытия или вымышленные Issue-номера. Внести только реальные результаты выполнения.
