"""HTML-экраны и JSON API; бизнес-правила находятся в services.py."""
import json
from datetime import date
from uuid import UUID

from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_POST

from . import services
from .forms import PaymentForm, ReserveForm, SearchForm
from .models import Booking


def home(request):
    """Экран Э-01: поиск номера."""
    form = SearchForm(request.GET or None)
    rooms = []
    error = None
    if request.GET and form.is_valid():
        try:
            rooms = services.search_rooms(**form.cleaned_data)
        except services.BookingError as exc:
            error = str(exc)
    return render(request, "hotelbook/search.html", {"form": form, "rooms": rooms, "error": error})


def reserve_page(request):
    """Экраны Э-03/Э-04: данные гостя и временный резерв."""
    initial = {key: request.GET.get(key) for key in ("room_id", "check_in", "check_out", "guests")}
    form = ReserveForm(request.POST or None, initial=initial)
    error = None
    if request.method == "POST" and form.is_valid():
        data = form.cleaned_data.copy()
        room_id = data.pop("room_id")
        try:
            booking = services.reserve_room(room_id=room_id, **data)
            return redirect("booking-detail", booking_id=booking.pk)
        except services.BookingError as exc:
            error = str(exc)
    if request.method == "POST" and form.is_valid() is False and form.errors:
        error = "Проверьте введённые данные."
    return render(request, "hotelbook/reserve.html", {"form": form, "error": error})


def booking_detail(request, booking_id):
    """Экраны Э-04/Э-05: состояние бронирования и результат оплаты."""
    booking = get_object_or_404(Booking.objects.select_related("room", "customer"), pk=booking_id)
    form = PaymentForm(request.POST or None)
    error = None
    if request.method == "POST" and form.is_valid():
        try:
            services.process_payment(booking.pk, form.cleaned_data["gateway_confirmed"])
            return redirect("booking-detail", booking_id=booking.pk)
        except services.BookingError as exc:
            error = str(exc)
            booking.refresh_from_db()
    return render(request, "hotelbook/detail.html", {"booking": booking, "form": form, "error": error})


@require_GET
def api_rooms(request):
    """GET /api/rooms/: поиск доступных номеров из БД."""
    form = SearchForm(request.GET)
    if not form.is_valid():
        return JsonResponse({"errors": form.errors.get_json_data()}, status=400)
    try:
        rooms = services.search_rooms(**form.cleaned_data)
    except services.BookingError as exc:
        return JsonResponse({"error": str(exc)}, status=exc.http_status)
    nights = (form.cleaned_data["check_out"] - form.cleaned_data["check_in"]).days
    return JsonResponse({"items": [{
        "id": str(room.pk), "number": room.number, "category": room.get_category_display(),
        "capacity": room.capacity, "price_per_night": str(room.price_per_night),
        "total": str(room.price_per_night * nights),
    } for room in rooms]}, json_dumps_params={"ensure_ascii": False})


@require_POST
def api_reserve(request):
    """POST /api/bookings/reserve/: создать временный резерв (шаг 2 UC-01)."""
    try:
        data = json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Тело запроса должно быть JSON."}, status=400)
    form = ReserveForm(data)
    if not form.is_valid():
        return JsonResponse({"errors": form.errors.get_json_data()}, status=400)
    try:
        payload = form.cleaned_data.copy()
        room_id = payload.pop("room_id")
        booking = services.reserve_room(room_id=room_id, **payload)
    except services.BookingError as exc:
        return JsonResponse({"error": str(exc)}, status=exc.http_status,
                            json_dumps_params={"ensure_ascii": False})
    return JsonResponse({
        "booking_id": str(booking.pk), "status": booking.get_status_display(),
        "expires_at": booking.expires_at.isoformat(), "total": str(booking.total),
    }, status=201, json_dumps_params={"ensure_ascii": False})


@require_POST
def api_payment(request, booking_id):
    """POST /api/bookings/{id}/payment-result/: обработать ответ провайдера."""
    try:
        data = json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Тело запроса должно быть JSON."}, status=400)
    form = PaymentForm(data)
    if not form.is_valid():
        return JsonResponse({"errors": form.errors.get_json_data()}, status=400)
    try:
        booking = services.process_payment(booking_id, form.cleaned_data["gateway_confirmed"])
    except services.BookingError as exc:
        return JsonResponse({"error": str(exc)}, status=exc.http_status,
                            json_dumps_params={"ensure_ascii": False})
    return JsonResponse({"status": booking.get_status_display()}, status=200,
                        json_dumps_params={"ensure_ascii": False})
