from django.contrib import admin
from .models import Booking, BookingNight, Customer, Room


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ("number", "category", "capacity", "price_per_night", "condition")
    list_filter = ("category", "condition")
    search_fields = ("number",)


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("full_name", "phone", "email", "registered_at")
    search_fields = ("full_name", "phone", "email")


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("id", "customer", "room", "check_in", "check_out", "status", "total")
    list_filter = ("status", "check_in")
    search_fields = ("customer__full_name", "customer__phone", "room__number")


@admin.register(BookingNight)
class BookingNightAdmin(admin.ModelAdmin):
    list_display = ("room", "stay_date", "booking")
    list_filter = ("stay_date",)
