from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("book/reserve/", views.reserve_page, name="reserve-page"),
    path("bookings/<uuid:booking_id>/", views.booking_detail, name="booking-detail"),
    path("api/rooms/", views.api_rooms, name="api-rooms"),
    path("api/bookings/reserve/", views.api_reserve, name="api-reserve"),
    path("api/bookings/<uuid:booking_id>/payment-result/", views.api_payment, name="api-payment"),
]
