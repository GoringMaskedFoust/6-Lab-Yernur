"""Бизнес-логика HotelBook. Правила БП-01…БП-06 проверяются только здесь."""
from datetime import date, timedelta
from decimal import Decimal

from django.db import IntegrityError, transaction
from django.utils import timezone

from .models import Booking, BookingNight, Customer, Room

RESERVATION_MINUTES = 15  # БП-01: временный резерв действует 15 минут.
MAX_PAYMENT_ATTEMPTS = 3  # БП-04: допускается не более трёх попыток оплаты.
MAX_GUESTS = 10


class BookingError(Exception):
    """Базовое исключение сценария UC-01."""

    http_status = 400

    def __init__(self, message=None):
        self.message = message or self.message
        super().__init__(self.message)


class RoomUnavailableError(BookingError):
    """Номер занят или недоступен."""

    http_status = 409
    message = "Номер уже занят на выбранные даты."


class CapacityExceededError(BookingError):
    """Число гостей превышает вместимость номера."""

    http_status = 422
    message = "Количество гостей превышает вместимость номера."


class ReservationExpiredError(BookingError):
    """Срок временного резерва истёк."""

    http_status = 410
    message = "Срок временного резервирования истёк."


class PaymentDeclinedError(BookingError):
    """Платёж отклонён провайдером."""

    http_status = 402
    message = "Платёж не подтверждён платёжным провайдером."


class TooManyPaymentAttemptsError(BookingError):
    """Исчерпан лимит попыток оплаты."""

    http_status = 422
    message = "Достигнут лимит в три попытки оплаты."


class InvalidStateError(BookingError):
    """Операция недопустима для текущего состояния брони."""

    http_status = 409
    message = "Операция недопустима для текущего состояния бронирования."


def validate_stay(check_in: date, check_out: date, guests: int) -> None:
    """Шаг 1 UC-01: проверить даты и количество гостей (БП-01, БП-02)."""
    if check_in < timezone.localdate():
        raise BookingError("Дата заезда не может быть раньше текущей даты.")
    if check_out <= check_in:
        raise BookingError("Дата выезда должна быть позже даты заезда.")
    if not 1 <= guests <= MAX_GUESTS:
        raise BookingError("Количество гостей должно быть от 1 до 10.")


def search_rooms(check_in: date, check_out: date, guests: int):
    """Шаг 1 UC-01: найти доступные номера и рассчитать стоимость."""
    validate_stay(check_in, check_out, guests)
    now = timezone.now()
    active = Booking.objects.filter(
        status=Booking.Status.PENDING, expires_at__gt=now
    ) | Booking.objects.filter(status=Booking.Status.CONFIRMED)
    occupied_ids = active.filter(
        check_in__lt=check_out, check_out__gt=check_in
    ).values_list("room_id", flat=True)
    return Room.objects.filter(
        condition=Room.Condition.ACTIVE, capacity__gte=guests
    ).exclude(pk__in=occupied_ids)


@transaction.atomic
def reserve_room(room_id, check_in: date, check_out: date, guests: int,
                 full_name: str, phone: str, email: str, consent: bool, extras=None):
    """Шаг 2 UC-01: повторно проверить номер и создать 15-минутный резерв (БП-01, БП-02)."""
    validate_stay(check_in, check_out, guests)
    room = Room.objects.select_for_update().filter(pk=room_id, condition=Room.Condition.ACTIVE).first()
    if room is None:
        raise RoomUnavailableError("Номер не найден или не эксплуатируется.")
    if guests > room.capacity:
        raise CapacityExceededError()
    now = timezone.now()
    expired_ids = list(Booking.objects.filter(
        room=room, status=Booking.Status.PENDING, expires_at__lte=now
    ).values_list("pk", flat=True))
    if expired_ids:
        BookingNight.objects.filter(booking_id__in=expired_ids).delete()
        Booking.objects.filter(pk__in=expired_ids).update(status=Booking.Status.FAILED)
    overlap = Booking.objects.filter(
        room=room, check_in__lt=check_out, check_out__gt=check_in
    ).filter(
        models_q_pending(now)
    ).exists()
    if overlap:
        raise RoomUnavailableError()
    customer, _ = Customer.objects.get_or_create(
        phone=phone,
        defaults={"full_name": full_name, "email": email, "personal_data_consent": consent},
    )
    if customer.full_name != full_name or customer.email != email:
        customer.full_name, customer.email = full_name, email
        customer.personal_data_consent = consent
        customer.save(update_fields=["full_name", "email", "personal_data_consent"])
    total = room.price_per_night * (check_out - check_in).days
    extra_prices = {"breakfast": Decimal("3500.00"), "transfer": Decimal("5000.00"),
                    "late_checkout": Decimal("4000.00")}
    for code in extras or []:
        total += extra_prices.get(code, Decimal("0.00"))
    try:
        # Вложенная транзакция откатывает бронь и все ночи, если уникальная ночь уже занята.
        with transaction.atomic():
            booking = Booking.objects.create(
                customer=customer, room=room, check_in=check_in, check_out=check_out,
                guests=guests, total=total, status=Booking.Status.PENDING,
                expires_at=now + timedelta(minutes=RESERVATION_MINUTES), extras=extras or [],
            )
            BookingNight.objects.bulk_create([
                BookingNight(booking=booking, room=room, stay_date=check_in + timedelta(days=offset))
                for offset in range((check_out - check_in).days)
            ])
        return booking
    except IntegrityError as exc:
        raise RoomUnavailableError() from exc


def models_q_pending(now):
    """Условие активной занятости: подтверждённая бронь или действующий резерв."""
    from django.db.models import Q
    return Q(status=Booking.Status.CONFIRMED) | Q(
        status=Booking.Status.PENDING, expires_at__gt=now
    )


def process_payment(booking_id, gateway_confirmed: bool):
    """Шаги 4–5 UC-01: обработать результат провайдера и применить БП-03/БП-04."""
    error = None
    booking = None
    with transaction.atomic():
        booking = Booking.objects.select_for_update().filter(pk=booking_id).first()
        if booking is None:
            raise BookingError("Бронирование не найдено.")
        if booking.status != Booking.Status.PENDING:
            raise InvalidStateError()
        if not booking.expires_at or booking.expires_at <= timezone.now():
            booking.status = Booking.Status.FAILED
            booking.save(update_fields=["status"])
            booking.nights.all().delete()
            error = ReservationExpiredError()
        elif gateway_confirmed:
            booking.status = Booking.Status.CONFIRMED
            booking.save(update_fields=["status"])
        else:
            booking.payment_attempts += 1
            if booking.payment_attempts >= MAX_PAYMENT_ATTEMPTS:
                booking.status = Booking.Status.FAILED
                error = TooManyPaymentAttemptsError()
            else:
                error = PaymentDeclinedError()
            booking.save(update_fields=["payment_attempts", "status"])
            if booking.status == Booking.Status.FAILED:
                booking.nights.all().delete()
    if error:
        raise error
    return booking


def cancellation_refund(check_in: date, now: date, amount: Decimal) -> Decimal:
    """Шаг отмены UC-01: рассчитать возврат по БП-05."""
    return amount if (check_in - now).days >= 1 else Decimal("0.00")
