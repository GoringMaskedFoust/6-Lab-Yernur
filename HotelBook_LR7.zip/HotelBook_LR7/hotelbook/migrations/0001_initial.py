# Generated for HotelBook laboratory work №7.
import uuid
from django.db import migrations, models
import django.db.models.deletion
from django.db.models import Q


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Customer",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False, verbose_name="ID")),
                ("full_name", models.CharField(max_length=150, verbose_name="ФИО")),
                ("phone", models.CharField(max_length=12, verbose_name="Телефон")),
                ("email", models.EmailField(max_length=254, verbose_name="Электронная почта")),
                ("registered_at", models.DateTimeField(auto_now_add=True, verbose_name="Дата регистрации")),
                ("personal_data_consent", models.BooleanField(default=False, verbose_name="Согласие на обработку данных")),
            ],
            options={"verbose_name": "Клиент", "verbose_name_plural": "Клиенты"},
        ),
        migrations.CreateModel(
            name="Room",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False, verbose_name="ID")),
                ("number", models.CharField(max_length=10, unique=True, verbose_name="Номер комнаты")),
                ("category", models.CharField(choices=[("standard", "Стандарт"), ("comfort", "Комфорт"), ("lux", "Люкс")], max_length=10, verbose_name="Категория")),
                ("capacity", models.PositiveSmallIntegerField(verbose_name="Вместимость")),
                ("price_per_night", models.DecimalField(decimal_places=2, max_digits=10, verbose_name="Цена за ночь")),
                ("condition", models.CharField(choices=[("active", "В эксплуатации"), ("repair", "На ремонте")], default="active", max_length=10, verbose_name="Состояние эксплуатации")),
            ],
            options={"ordering": ["number"], "verbose_name": "Номер", "verbose_name_plural": "Номера"},
        ),
        migrations.CreateModel(
            name="Booking",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False, verbose_name="ID")),
                ("check_in", models.DateField(verbose_name="Дата заезда")),
                ("check_out", models.DateField(verbose_name="Дата выезда")),
                ("guests", models.PositiveSmallIntegerField(verbose_name="Количество гостей")),
                ("total", models.DecimalField(decimal_places=2, max_digits=10, verbose_name="Общая стоимость")),
                ("status", models.CharField(choices=[("created", "Создано"), ("pending", "Ожидает оплаты"), ("confirmed", "Подтверждено"), ("checked_in", "Заселён"), ("completed", "Завершено"), ("cancelled", "Отменено"), ("failed", "Неуспешно")], default="created", max_length=12, verbose_name="Состояние")),
                ("payment_attempts", models.PositiveSmallIntegerField(default=0, verbose_name="Количество попыток оплаты")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")),
                ("expires_at", models.DateTimeField(blank=True, null=True, verbose_name="Окончание резерва")),
                ("extras", models.JSONField(blank=True, default=list, verbose_name="Дополнительные услуги")),
                ("customer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="bookings", to="hotelbook.customer", verbose_name="Клиент")),
                ("room", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="bookings", to="hotelbook.room", verbose_name="Номер")),
            ],
            options={"ordering": ["-created_at"], "verbose_name": "Бронирование", "verbose_name_plural": "Бронирования"},
        ),
        migrations.CreateModel(
            name="BookingNight",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("stay_date", models.DateField(verbose_name="Дата проживания")),
                ("booking", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="nights", to="hotelbook.booking", verbose_name="Бронирование")),
                ("room", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="booked_nights", to="hotelbook.room", verbose_name="Номер")),
            ],
            options={"ordering": ["stay_date"], "verbose_name": "Ночь бронирования", "verbose_name_plural": "Ночи бронирования"},
        ),
        migrations.AddConstraint(model_name="bookingnight", constraint=models.UniqueConstraint(fields=("room", "stay_date"), name="unique_room_stay_date")),
        migrations.AddConstraint(model_name="room", constraint=models.CheckConstraint(condition=Q(("capacity__gte", 1), ("capacity__lte", 10)), name="room_capacity_1_10")),
        migrations.CreateModel(
            name="BookingNight",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("stay_date", models.DateField(verbose_name="Дата проживания")),
                ("booking", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="nights", to="hotelbook.booking", verbose_name="Бронирование")),
                ("room", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="booked_nights", to="hotelbook.room", verbose_name="Номер")),
            ],
            options={"ordering": ["stay_date"], "verbose_name": "Ночь бронирования", "verbose_name_plural": "Ночи бронирования"},
        ),
        migrations.AddConstraint(model_name="bookingnight", constraint=models.UniqueConstraint(fields=("room", "stay_date"), name="unique_room_stay_date")),
        migrations.AddConstraint(model_name="room", constraint=models.CheckConstraint(condition=Q(("price_per_night__gte", 0)), name="room_price_nonnegative")),
        migrations.AddConstraint(model_name="booking", constraint=models.CheckConstraint(condition=Q(("check_out__gt", models.F("check_in"))), name="booking_checkout_after_checkin")),
        migrations.AddConstraint(model_name="booking", constraint=models.CheckConstraint(condition=Q(("guests__gte", 1), ("guests__lte", 10)), name="booking_guests_1_10")),
        migrations.AddConstraint(model_name="booking", constraint=models.CheckConstraint(condition=Q(("payment_attempts__lte", 3)), name="booking_attempts_at_most_3")),
        migrations.AddConstraint(model_name="booking", constraint=models.CheckConstraint(condition=Q(("total__gte", 0)), name="booking_total_nonnegative")),
        migrations.AddConstraint(model_name="booking", constraint=models.UniqueConstraint(fields=("room", "check_in", "check_out"), name="unique_room_exact_period")),
    ]
