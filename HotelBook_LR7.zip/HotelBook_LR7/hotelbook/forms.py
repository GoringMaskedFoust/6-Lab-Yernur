"""Формы отвечают только за формат и обязательность ввода."""
from django import forms
from .models import Room


class SearchForm(forms.Form):
    check_in = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    check_out = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    guests = forms.IntegerField(min_value=1, max_value=10, initial=2)


class ReserveForm(forms.Form):
    room_id = forms.UUIDField(widget=forms.HiddenInput)
    check_in = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    check_out = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    guests = forms.IntegerField(min_value=1, max_value=10)
    full_name = forms.CharField(min_length=2, max_length=150)
    phone = forms.RegexField(regex=r"^\+7[0-9]{10}$", max_length=12)
    email = forms.EmailField(max_length=254)
    consent = forms.BooleanField(required=True)
    extras = forms.MultipleChoiceField(required=False, choices=[
        ("breakfast", "Завтрак"), ("transfer", "Трансфер"),
        ("late_checkout", "Поздний выезд"),
    ])


class PaymentForm(forms.Form):
    gateway_confirmed = forms.BooleanField(required=False)
