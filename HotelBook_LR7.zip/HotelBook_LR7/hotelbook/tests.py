from datetime import timedelta
from django.test import TestCase
from django.utils import timezone

from . import services
from .models import Booking, Customer, Room


class HotelBookUC01Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.room = Room.objects.create(number="301", category=Room.Category.STANDARD,
            capacity=2, price_per_night="18000.00")
        cls.room2 = Room.objects.create(number="402", category=Room.Category.COMFORT,
            capacity=3, price_per_night="25000.00")
        cls.customer = Customer.objects.create(full_name="Тестовый Клиент",
            phone="+77011234567", email="test@example.com", personal_data_consent=True)

    def dates(self):
        today = timezone.localdate()
        return today + timedelta(days=1), today + timedelta(days=3)

    def reserve(self, room=None, guests=2, phone="+77011234567"):
        start, end = self.dates()
        return services.reserve_room(
            (room or self.room).pk, start, end, guests, "Тестовый Клиент",
            phone, "test@example.com", True, []
        )

    def test_search_returns_database_rooms(self):
        """Основной поток UC-01: поиск доступных номеров из БД."""
        start, end = self.dates()
        self.assertIn(self.room, services.search_rooms(start, end, 2))

    def test_reserve_creates_pending_booking_for_15_minutes(self):
        """БП-01/БП-02: резерв создаётся на 15 минут и ожидает оплаты."""
        booking = self.reserve()
        self.assertEqual(booking.status, Booking.Status.PENDING)
        seconds = (booking.expires_at - timezone.now()).total_seconds()
        self.assertAlmostEqual(seconds, 900, delta=5)

    def test_overlapping_room_reservation_is_rejected(self):
        """Исключение Е3: занятый номер возвращает конфликт даже при частичном пересечении."""
        self.reserve()
        start, _ = self.dates()
        with self.assertRaises(services.RoomUnavailableError):
            services.reserve_room(
                self.room.pk, start + timedelta(days=1), start + timedelta(days=4),
                2, "Другой клиент", "+77019999999", "other@example.com", True, []
            )

    def test_capacity_boundary_one_and_room_limit(self):
        """БП-02: обе допустимые границы вместимости номера."""
        self.assertEqual(self.reserve(guests=1).guests, 1)
        self.room2.capacity = 3
        self.room2.save()
        self.assertEqual(self.reserve(room=self.room2, guests=3).guests, 3)

    def test_capacity_exceeded_raises_422(self):
        """БП-02: превышение вместимости вызывает исключение."""
        with self.assertRaises(services.CapacityExceededError):
            self.reserve(guests=3)

    def test_successful_payment_confirms_booking(self):
        """БП-03: подтверждение возможно после положительного ответа шлюза."""
        booking = self.reserve()
        result = services.process_payment(booking.pk, True)
        self.assertEqual(result.status, Booking.Status.CONFIRMED)

    def test_third_declined_payment_closes_booking(self):
        """БП-04/Е1: третья неудачная попытка закрывает бронь."""
        booking = self.reserve()
        for _ in range(2):
            with self.assertRaises(services.PaymentDeclinedError):
                services.process_payment(booking.pk, False)
        with self.assertRaises(services.TooManyPaymentAttemptsError):
            services.process_payment(booking.pk, False)
        booking.refresh_from_db()
        self.assertEqual(booking.payment_attempts, 3)
        self.assertEqual(booking.status, Booking.Status.FAILED)

    def test_expired_reservation_cannot_be_confirmed(self):
        """Е2/БП-01: истёкший резерв становится неуспешным."""
        booking = self.reserve()
        Booking.objects.filter(pk=booking.pk).update(expires_at=timezone.now() - timedelta(seconds=1))
        with self.assertRaises(services.ReservationExpiredError):
            services.process_payment(booking.pk, True)
        booking.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.FAILED)

    def test_api_reserve_returns_201_and_persists(self):
        """Контракт API: POST резерва создаёт запись в БД."""
        start, end = self.dates()
        response = self.client.post("/api/bookings/reserve/", data={
            "room_id": str(self.room2.pk), "check_in": start.isoformat(),
            "check_out": end.isoformat(), "guests": 2, "full_name": "Новый Клиент",
            "phone": "+77019999999", "email": "new@example.com", "consent": True,
            "extras": [],
        }, content_type="application/json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(Booking.objects.filter(pk=response.json()["booking_id"]).exists())

    def test_api_invalid_phone_returns_400(self):
        """Формат ввода: неверный телефон отклоняется до бизнес-логики."""
        start, end = self.dates()
        response = self.client.post("/api/bookings/reserve/", data={
            "room_id": str(self.room.pk), "check_in": start.isoformat(),
            "check_out": end.isoformat(), "guests": 1, "full_name": "Тест",
            "phone": "8701", "email": "test@example.com", "consent": True,
            "extras": [],
        }, content_type="application/json")
        self.assertEqual(response.status_code, 400)

    def test_cancellation_refund_rule_boundary(self):
        """БП-05: возврат зависит от срока до заезда."""
        today = timezone.localdate()
        amount = Decimal("10000.00")
        self.assertEqual(services.cancellation_refund(today + timedelta(days=1), today, amount), amount)
        self.assertEqual(services.cancellation_refund(today, today, amount), Decimal("0.00"))

    def test_search_screen_and_rooms_api(self):
        """Э-01 и GET API используют записи базы данных."""
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        start, end = self.dates()
        api = self.client.get("/api/rooms/", {
            "check_in": start.isoformat(), "check_out": end.isoformat(), "guests": 2
        })
        self.assertEqual(api.status_code, 200)
        self.assertGreaterEqual(len(api.json()["items"]), 2)
