"""Модели данных HotelBook для UC-01."""
import uuid

from django.db import models
from django.db.models import Q


class Room(models.Model):
    class Category(models.TextChoices):
        STANDARD = "standard", "Стандарт"
        COMFORT = "comfort", "Комфорт"
        LUX = "lux", "Люкс"

    class Condition(models.TextChoices):
        ACTIVE = "active", "В эксплуатации"
        REPAIR = "repair", "На ремонте"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, verbose_name="ID")
    number = models.CharField(max_length=10, unique=True, verbose_name="Номер комнаты")
    category = models.CharField(max_length=10, choices=Category.choices, verbose_name="Категория")
    capacity = models.PositiveSmallIntegerField(verbose_name="Вместимость")
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена за ночь")
    condition = models.CharField(max_length=10, choices=Condition.choices, default=Condition.ACTIVE,
                                 verbose_name="Состояние эксплуатации")

    class Meta:
        ordering = ["number"]
        verbose_name = "Номер"
        verbose_name_plural = "Номера"
        constraints = [
            models.CheckConstraint(condition=Q(capacity__gte=1) & Q(capacity__lte=10), name="room_capacity_1_10"),
            models.CheckConstraint(condition=Q(price_per_night__gte=0), name="room_price_nonnegative"),
        ]

    def __str__(self):
        return f"№ {self.number} — {self.get_category_display()}"


class Customer(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, verbose_name="ID")
    full_name = models.CharField(max_length=150, verbose_name="ФИО")
    phone = models.CharField(max_length=12, verbose_name="Телефон")
    email = models.EmailField(max_length=254, verbose_name="Электронная почта")
    registered_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата регистрации")
    personal_data_consent = models.BooleanField(default=False, verbose_name="Согласие на обработку данных")

    class Meta:
        verbose_name = "Клиент"
        verbose_name_plural = "Клиенты"

    def __str__(self):
        return f"{self.full_name} ({self.phone})"


class Booking(models.Model):
    class Status(models.TextChoices):
        CREATED = "created", "Создано"
        PENDING = "pending", "Ожидает оплаты"
        CONFIRMED = "confirmed", "Подтверждено"
        CHECKED_IN = "checked_in", "Заселён"
        COMPLETED = "completed", "Завершено"
        CANCELLED = "cancelled", "Отменено"
        FAILED = "failed", "Неуспешно"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, verbose_name="ID")
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="bookings", verbose_name="Клиент")
    room = models.ForeignKey(Room, on_delete=models.PROTECT, related_name="bookings", verbose_name="Номер")
    check_in = models.DateField(verbose_name="Дата заезда")
    check_out = models.DateField(verbose_name="Дата выезда")
    guests = models.PositiveSmallIntegerField(verbose_name="Количество гостей")
    total = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Общая стоимость")
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.CREATED, verbose_name="Состояние")
    payment_attempts = models.PositiveSmallIntegerField(default=0, verbose_name="Количество попыток оплаты")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name="Окончание резерва")
    extras = models.JSONField(default=list, blank=True, verbose_name="Дополнительные услуги")

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Бронирование"
        verbose_name_plural = "Бронирования"
        constraints = [
            models.CheckConstraint(condition=Q(check_out__gt=models.F("check_in")), name="booking_checkout_after_checkin"),
            models.CheckConstraint(condition=Q(guests__gte=1) & Q(guests__lte=10), name="booking_guests_1_10"),
            models.CheckConstraint(condition=Q(payment_attempts__lte=3), name="booking_attempts_at_most_3"),
            models.CheckConstraint(condition=Q(total__gte=0), name="booking_total_nonnegative"),
            models.UniqueConstraint(fields=["room", "check_in", "check_out"], name="unique_room_exact_period"),
        ]

    def __str__(self):
        return f"Бронь {self.id} — {self.room} ({self.get_status_display()})"


class BookingNight(models.Model):
    """Занятая ночь; уникальность пары номер/дата блокирует пересечение броней в БД."""

    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="nights", verbose_name="Бронирование")
    room = models.ForeignKey(Room, on_delete=models.PROTECT, related_name="booked_nights", verbose_name="Номер")
    stay_date = models.DateField(verbose_name="Дата проживания")

    class Meta:
        ordering = ["stay_date"]
        verbose_name = "Ночь бронирования"
        verbose_name_plural = "Ночи бронирования"
        constraints = [
            models.UniqueConstraint(fields=["room", "stay_date"], name="unique_room_stay_date"),
        ]

    def __str__(self):
        return f"{self.room} — {self.stay_date}"
