# Трассировка UC-01 — HotelBook, ЛР №7

| Правило / исключение | Функция слоя логики | Класс исключения | HTTP | Проверяющий тест |
|---|---|---|---:|---|
| БП-01: резерв на 15 минут; истечение срока | `reserve_room`, `process_payment` | `ReservationExpiredError` | 410 | `test_reserve_creates_pending_booking_for_15_minutes`, `test_expired_reservation_cannot_be_confirmed` |
| БП-02: вместимость номера | `validate_stay`, `reserve_room` | `CapacityExceededError` | 422 | `test_capacity_boundary_one_and_room_limit`, `test_capacity_exceeded_raises_422` |
| БП-03: подтверждение только после успеха провайдера | `process_payment` | `PaymentDeclinedError` | 402 | `test_successful_payment_confirms_booking` |
| БП-04 / Е1: максимум три попытки | `process_payment` | `PaymentDeclinedError`, `TooManyPaymentAttemptsError` | 402 / 422 | `test_third_declined_payment_closes_booking` |
| Е3: номер занят на пересекающиеся даты | `reserve_room` | `RoomUnavailableError` | 409 | `test_overlapping_room_reservation_is_rejected` |
| БП-05: расчёт возврата при отмене | `cancellation_refund` | — | — | `test_cancellation_refund_rule_boundary` |
| Ошибка формата телефона | `ReserveForm` (слой представления) | Ошибка формы | 400 | `test_api_invalid_phone_returns_400` |
| Основной поток: поиск и создание резерва | `search_rooms`, `reserve_room` | — | 200 / 201 | `test_search_returns_database_rooms`, `test_api_reserve_returns_201_and_persists` |

## Защита от двойного бронирования

Создание резерва выполняется внутри `transaction.atomic()`. Для каждой ночи проживания создаётся строка `BookingNight`; ограничение БД `unique_room_stay_date` запрещает занять один номер на одну и ту же ночь двумя бронями. При конфликте вся вложенная транзакция откатывается, а сервис возвращает `RoomUnavailableError` (409). В PostgreSQL дополнительно применяется `select_for_update()` к строке номера. Это защищает и от частично пересекающихся периодов, а не только от полностью совпадающих дат.

## Границы реализации
БП-06 (разграничение доступа клиента, сотрудника и менеджера) зависит от модуля `accounts`, который в каркасе ЛР №6 обозначен как отдельный последующий модуль, но не реализован. Поэтому в учебной версии ЛР №7 интерфейс не предназначен для реальных персональных данных. Проверка прав доступа должна быть подключена вместе с аутентификацией до эксплуатации. Отмена подтверждённой брони по БП-05 также остаётся отдельной операцией следующего этапа; в этой работе реализован и проверен расчёт суммы возврата.
