# HotelBook — система онлайн-бронирования номеров

Лабораторная работа №6. Учебный каркас для сценария UC-01.

## Стек
Python 3.12+, Django 5.2, SQLite для локальной разработки; PostgreSQL — целевая СУБД.
Подробное обоснование: `docs/adr/ADR-001-stack.md`.

## Запуск
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```
Откройте http://127.0.0.1:8000/

## API
- `GET /api/rooms/?check_in=YYYY-MM-DD&check_out=YYYY-MM-DD&guests=2`
- `POST /api/bookings/reserve/` — JSON: `room_id`, `check_in`, `check_out`, `guests`
- `POST /api/bookings/<id>/pay/` — демонстрационный контракт ответа платёжного шлюза.

## Проверка
```bash
python manage.py test
ruff check .
ruff format --check .
```

## Структура
- `hotelbook/models.py` — модели Room, Customer и Booking.\n- `hotelbook/services.py` — бизнес-логика, БП-01…БП-06 и исключения UC-01.\n- `hotelbook/forms.py` — проверка формата ввода.\n- `hotelbook/migrations/` — миграции структуры БД.\n- `docs/defects.md` — журнал дефектов ЛР №7.
- `hotelbook/views.py` — представление и HTTP API.
- `templates/hotelbook/search.html` — Э-01.
- `docs/adr/` — архитектурное решение.
- `docs/architecture.md` — схема архитектуры.

## Важное ограничение учебного скелета
Платёжный шлюз пока представлен учебным переключателем подтверждения; реальные реквизиты карт не принимаются и не хранятся. Авторизация, отправка e-mail и интеграция с платёжным провайдером должны быть реализованы на следующих этапах. Не используйте этот каркас для обработки реальных платежей или персональных данных.

## Соглашения о коде
| Правило | Соглашение |
|---|---|
| Стиль | PEP 8; `ruff format`, длина строки по настройке Ruff |
| Имена | `snake_case` для функций и переменных, `PascalCase` для классов |
| Комментарии | На русском; публичные функции документируются docstring |
| Слои | Правила БП находятся в `services.py`, HTTP-обработчики — в `views.py` |
| Проверки | `python manage.py test` и `ruff check .` перед коммитом |
| Коммиты | Conventional Commits: `feat`, `fix`, `docs`, `test`, `refactor`, `chore` |
| Секреты | Секреты и пароли не хранятся в Git; для реального запуска использовать переменные окружения |
